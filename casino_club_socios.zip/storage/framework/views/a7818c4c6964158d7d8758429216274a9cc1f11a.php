<?php $__env->startSection('content'); ?>
<div class="row">

    <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel panel-inverse col-sm-12 col-md-12 col-lg-4 col-xl-4 bg-transparent" >
                <div class="panel-heading ui-sortable-handle">
                    <h4 class="panel-title">
                        QR Menu - <?php echo e($item_sede->name); ?>

                    </h4>
                </div>
                <div class="panel-body">
                    <div class="title m-b-md m-auto text-center">
                    <?php echo QrCode::size(300)->generate(Request::url().'/menu/'.$item_sede->id); ?>

                    </div>
                </div>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    $('#graphics_nav').removeClass("closed").addClass("active").addClass("expand")
</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casino_club_socios\resources\views/graphics/index.blade.php ENDPATH**/ ?>