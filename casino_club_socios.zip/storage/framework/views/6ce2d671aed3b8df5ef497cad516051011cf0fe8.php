<?php $__env->startSection('content'); ?>
    <div class="login login-with-news-feed">
        <div class="news-feed">
            <div class="news-image" style="background-image: url('<?php echo e(asset('img/login-bg/login-bg-11.jpg')); ?> ')"></div>
            <div class="news-caption">
                <h4 class="caption-title"><b>CASINOS RORAIMA</b></h4>
                <p>Desarrollado por el departamento de Sistemas</p>
            </div>
        </div>
        <div class="right-content">
            <div class="login-header">
                <div class="brand">
                    <small>Ingrese sus Credenciales</small>
                </div>
                <div class="icon">
                    <i class="fa fa-sign-in"></i>
                </div>
            </div>
            <div class="login-content">
                <form method="POST" action="<?php echo e(route('login')); ?>" class="margin-bottom-0">
                    <?php echo csrf_field(); ?>
                    <div class="form-group m-b-15">
                        <input type="text" name="email" class="form-control form-control-lg  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Usuario" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus />
                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group m-b-15">
                        <input type="password" name="password" class="form-control form-control-lg <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Contraseña" required autocomplete="current-password" />
                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="login-buttons">
                        <button type="submit" class="btn btn-primary btn-block btn-lg">Ingresar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casino_club_socios\resources\views/auth/login.blade.php ENDPATH**/ ?>