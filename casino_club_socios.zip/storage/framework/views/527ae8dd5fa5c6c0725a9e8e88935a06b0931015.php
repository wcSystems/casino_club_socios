<?php $__env->startSection('content'); ?>
<div class="panel panel-inverse" data-sortable-id="table-basic-1">
    <div class="panel-heading ui-sortable-handle">
        <h4 class="panel-title"></h4>
        <div class="panel-heading-btn">
            <button onclick="modal('Crear')" class="d-flex btn btn-1 btn-success">
                <i class="m-auto fa fa-lg fa-plus"></i>
            </button>
        </div>
    </div>
    <div class="panel-body">
        <div class="table-responsive">
            <table id="data-table-default" class="table table-bordered table-td-valign-middle" style="width:100% !important">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nombre y Apellido</th>
                        <th>Usuario</th>
                        <th>Nivel</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $('#users_nav').removeClass("closed").addClass("active").addClass("expand")
    function modal(type,id) {
        Swal.fire({
            title: `${type} Registro`,
            showConfirmButton: false,
            html:`
                <form id="form-all" class="needs-validation" action="javascript:void(0);" novalidate>
                <?php echo csrf_field(); ?>
                    <div class="row">

                        

                            <div class="mx-auto">
                                <label class="d-flex m-0">
                                    <img id="imgUser" class="rounded-circle" src="<?php echo e(url('public/users/${id}.jpg')); ?>" onerror="this.onerror=null;this.src='public/users/null.jpg';" width="200" height="200" />
                                    <input require onchange="viewImg(this)" type="file" id="image" name="image" style="display:none" >
                                </label>
                            </div>
                        


                        <div class="col-md-12 col-sm-12">
                            <div class="form-group row m-b-0">
                                <label class=" text-lg-right col-form-label"> Usuario <span class="text-danger"> *</span> </label>
                                <div class="col-lg-12">
                                    <input required type="text" id="email" name="email" class="form-control parsley-normal upper" style="color: var(--global-2) !important" placeholder="Defina el usuario aqui..." >
                                    <div class="invalid-feedback text-left">Error campo obligatorio.</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group row m-b-0">
                                <label class=" text-lg-right col-form-label"> Nombre y Apellido <span class="text-danger"> *</span> </label>
                                <div class="col-lg-12">
                                    <input required type="text" id="name" name="name" class="form-control parsley-normal upper" style="color: var(--global-2) !important" placeholder="Defina el Nombre y Apellido aqui..." >
                                    <div class="invalid-feedback text-left">Error campo obligatorio.</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group row m-b-0">
                                <label class=" text-lg-right col-form-label"> Passowrd <span class="text-danger"> *</span> </label>
                                <div class="col-lg-12">
                                    <input required type="password" id="password" name="password" class="form-control parsley-normal upper" style="color: var(--global-2) !important" placeholder="Defina el Password aqui..." >
                                    <div class="invalid-feedback text-left">Error campo obligatorio.</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12">
                            <div class="form-group row m-b-0">
                                <label class=" text-lg-right col-form-label"> Nivel <span class="text-danger"> *</span> </label>
                                <div class="col-lg-12">
                                    <select required id="level" class="form-control w-100">
                                        <option value="" selected >Todos los niveles</option>
                                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" > <?php echo e($item->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div class="invalid-feedback text-left">Error campo obligatorio.</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12" style="margin-top:20px">
                            <button onclick="guardar(${id})" type="submit" class="swal2-confirm swal2-styled" aria-label="" style="display: inline-block;"> Guardar </button>
                        </div>
                    </div>
                </form>`
        })
        if(id){
            let current=<?php echo $users; ?>.find(i=>i.id===id)
            $("#email").val(current.email)
            $("#name").val(current.name)
            $("#password").removeAttr('required');
            $("#level").val(current.level_id)
        }
        validateForm()
    }
    function guardar(id) {
        let validity = document.getElementById('form-all').checkValidity()
        if(validity){
            


            let payload = new FormData();   
                payload.append('id',id ? id : "")
                payload.append('name',$('#name').val())
                payload.append('email',$('#email').val())
                
                payload.append('level_id',$('#level').val())
                payload.append('image',$('#image').prop('files')[0])

                
                if(id && $('#password').val() != "" || !id ){
                    payload.append('password',$('#password').val())
                }

            $.ajax({
                url: "<?php echo e(route('users.store')); ?>",
                type: "POST",
                data: payload,
                processData: false,
                contentType: false,
                enctype: 'multipart/form-data',
                headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                success: function (res) {
                    console.log(res)
                    if(res.type === 'success'){
                        location.reload();
                    }
                    if(res.type === 'repeat'){
                        alertas('ERROR!','Este usuario ya se encuentra registrado, porfavor elija otro.','info')
                    }
                }
            });





        }
    }

    function viewImg(input) {
        if (input.files && input.files[0]) {
            let reader = new FileReader();
            reader.onload = function (e) {
                $('#imgUser').attr('src', e.target.result).width(200).height(200);
                $("#btnChangeIMG").addClass("d-none")
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    dataTable("<?php echo e(route('users.service')); ?>",[
        {
            render: function ( data,type, row,all  ) {
                return all.row+1;
            }
        },
        { data: 'name' },
        { data: 'email' },
        { data: 'level_name' },
        {
            render: function ( data,type, row  ) {
                let render = `<a onclick="elim('users',${row.id})" style="color: var(--global-2)" class="btn btn-danger btn-icon btn-circle"><i class="fa fa-times"></i></a>
                              <a onclick="modal('Editar',${row.id})" style="color: var(--global-2)" class="btn btn-yellow btn-icon btn-circle"><i class="fas fa-pen"></i></a>`
                return render;
            }
        },
    ])
</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\casino_club_socios\resources\views/users/index.blade.php ENDPATH**/ ?>