<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Img_global_warehouse extends Model
{
    protected $fillable = [
        'name',
        'global_warehouse_id',
    ];

    
}
