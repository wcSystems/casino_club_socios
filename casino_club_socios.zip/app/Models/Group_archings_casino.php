<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Group_archings_casino extends Model
{
    protected $fillable = [
        'sede_id',
        'created_at',
    ];
}
