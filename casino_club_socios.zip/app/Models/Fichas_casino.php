<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Fichas_casino extends Model
{
    protected $fillable = [
        'name',
        'sede_id',
    ];
}
