<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Horas_casino extends Model
{
    protected $fillable = [
        'name',
        'sede_id',
    ];
}
