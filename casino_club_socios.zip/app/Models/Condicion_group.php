<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Condicion_group extends Model
{
    protected $fillable = [
        'name',
    ];
}
