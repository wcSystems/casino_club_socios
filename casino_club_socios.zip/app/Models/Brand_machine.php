<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Brand_machine extends Model
{
    protected $fillable = [
        'name',
    ];
}
