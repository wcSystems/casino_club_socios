<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Novedades_type extends Model
{
    protected $fillable = [
        'name'
    ];
}
