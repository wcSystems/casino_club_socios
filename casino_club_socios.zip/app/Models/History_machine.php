<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class History_machine extends Model
{
    protected $fillable = [
        'name',
        'global_warehouse_id',
    ];
}
