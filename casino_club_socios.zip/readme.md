# Devs Only

LARAVEL - Casinos Roraima
- git clone https://github.com/wcSystems/casino_club_socios.git
- cd casino_club_socios
- composer install
- configure, copy and rename: .env-example -> .env
- php artisan migrate:refresh --seed
- php artisan serve

LOGIN
- user: willinthon, password: 12345678 

BRANCHS
- master: Rama Principal
